
---
title: columns
type: "categories"
categories: [前端, CSS]
---

#### column-width 列的宽度
### column-count 列的栏数
### column-gap 列的间距
### column-rule 列间距（宽度，样式，颜色)
### column-span: none || all 元素跨所有列

### 总结： 做出上三，中一，下三的效果