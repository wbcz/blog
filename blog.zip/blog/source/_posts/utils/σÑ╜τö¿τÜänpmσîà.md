---
title: 好用的npm包
type: "categories"
categories: 工具
---

## minist
 把node命令行的参数转为对象的形式
## shelljs
https://github.com/shelljs/shelljs
执行shell命令，比如可以把不常用的包编译一次，然后每次只需要用cp()移动进去即可，在webpack减少了编译时间
## ora
显示命令行状态图标的
## 同步获取所有路径
glob库，通过正则匹配到所有路径

## NProgress
实现进度条，一般用在ajax请求数据的时候

## qs
格式化url传递参数